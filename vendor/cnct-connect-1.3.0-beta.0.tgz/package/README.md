# @cnct/connect

**Sign in with Connections, in two calls.** Give your app real logins and real per-user data —
no backend, no AWS, no OAuth console. The auth client is dependency-free (Web Crypto + fetch);
it works in browsers, Chrome-extension service workers, and Node ≥ 18.

```sh
npm install @cnct/connect
```

One package, zero dependencies. Sign-in and the per-user data locker ship together — no second
install, no peer to satisfy, nothing for a bundler to fail to resolve.

```ts
import { createConnect, createSettingsSync } from "@cnct/connect";

const connect = createConnect({ clientId: "your-public-client-id" });

// Sign in without a callback route. The SDK supplies the responsive handoff dialog;
// credentials and consent remain in the secure Connections-owned window.
const user = await connect.signInDialog({ appName: "Your app" });
// { sub, name, email, ... }; session is persisted

// Carry a few keys of the settings store you ALREADY have between devices:
const sync = createSettingsSync(connect.locker(), {
  keys: ["theme", "density"],
  read: () => settingsStore.getAll(),
  write: (patch) => settingsStore.patch(patch),
});
await sync.hydrate({ seedIfEmpty: true }); // returning user: pull; first use: seed from read()
settingsStore.on("change", () => sync.push());
app.on("before-quit", () => sync.flushAndStop({ timeoutMs: 5_000 }));
```

`signInDialog()` is the recommended browser experience. It injects an isolated Connections dialog
into the current page, explains the secure handoff, and launches the issuer-owned OAuth window from
its own button. Popup-block recovery, retry, cancellation, focus restoration, dark mode, reduced
motion, and desktop/mobile layout are built in.

`signInPopup()` remains the lower-level browser primitive. It must be called from a click — browsers
block popups otherwise, and it throws `popup_blocked` rather than hanging. Prefer a top-level
redirect, or driving the flow yourself? `signIn()` + `handleCallback()` still work exactly as
before, and then you do need a route.

`createSettingsSync` guards the allowlist on two levels, and the difference matters. A key whose
NAME reads like a credential, path, device id, or window state gets a **console warning** —
`keyBindings`, `homeView`, `folderSort` and `windowTheme` are all ordinary portable preferences, so
a name is a hint, never grounds to refuse. A **value** matching a published credential format
(Stripe, OpenAI, GitHub, Slack, AWS, Google, a JWT, a PEM private key) is **refused outright**,
named, before a byte leaves the machine — including nested inside an object. `allowUnsafeKeys`
silences both for a named key. An oversized document is caught locally too, naming the key that
blew the 64 KB cap.

The sync engine keeps a baseline and sends the smallest RFC 7386 patch, including leaf-level
changes inside nested settings objects. Two devices can therefore change sibling preferences
without one device resending and overwriting the other's stale value. Reads and writes are
serialized, a pull that started before a local edit cannot overwrite it, transient network/5xx
failures retry with bounded backoff, 429s honor the server's delay, and the ETag cache is scoped to
the current access token. `status.serverSettings` exposes the latest backend-managed tier without
ever passing it to the writable store. Locker operations have a 30-second deadline by default;
every `get`/`set`/`merge`/`delete`/`versions`/`restore` call accepts `{ signal, timeoutMs }`, and
`flushAndStop({ timeoutMs })` aborts the active request when an app's shutdown budget expires.

### Vue

```ts
import { useSettingsSync } from "@cnct/connect/vue";

const { status, push } = useSettingsSync(connect.locker(), { keys, read, write });
```

It hydrates immediately, seeds an empty remote document, and flushes before stopping when the
surrounding scope is disposed — via
`onScopeDispose`, so it works inside a Pinia store or a bare `effectScope`, not only a component.
`useUserSettings(locker)` is the other shape, for when the locker _is_ your store. React has the
same pair at `@cnct/connect/react`.

### Testing your integration

`createMemoryLocker()` is the same client backed by memory, so your app's own tests cover the sync
path without stubbing `fetch` or touching production:

```ts
import { createMemoryLocker, createSettingsSync } from "@cnct/connect";

const sync = createSettingsSync(createMemoryLocker({ theme: "dark" }), { keys, read, write });
await sync.hydrate(); // exercises the returning-user path; seed it to test hydration
```

## Upgrading from 0.3.x

Three breaking changes, all mechanical:

| Was                                           | Now                                                                                                                           |
| --------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| `npm install @cnct/connect @cnct/locker`      | `npm install @cnct/connect` - one package, zero dependencies                                                                  |
| `import { createLocker } from "@cnct/locker"` | `import { createLocker } from "@cnct/connect"`                                                                                |
| `const locker = await connect.locker()`       | `const locker = connect.locker()` - **synchronous now**, and `await` on it is the one change a compiler will not always catch |

`@cnct/locker/react` moved to `@cnct/connect/react`. `createLocker({ appId, getToken })` is
otherwise unchanged, so every call site keeps working. `@cnct/locker` stays on npm frozen at 0.1.1
for existing installs; it will not get further releases.

## Stability: what 1.0 promises

**This is the last upgrade table you will read.** 1.0 means the API above is frozen for the whole
of `1.x`, so `npm install @cnct/connect` is safe to run and forget.

|                  | Ships in a `1.x` release                                                                     | Waits for `2.0`                                                                           |
| ---------------- | -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| **The SDK**      | New functions, new optional arguments, new fields on returned objects, bug fixes             | Renaming or removing anything you can call, or changing what it returns                   |
| **The HTTP API** | New endpoints, new response fields, new optional request fields, raised size and rate limits | Any change to what `/v1` already returns, which would arrive as `/v2` served alongside it |

The second row is the one that matters, and it is the one most SDKs quietly get wrong. Pinning the
package does not pin the server it talks to, so an "additive-only" promise about the wire protocol
is worth more than any amount of semver discipline in the client.

We hold ourselves to it mechanically rather than by intention: an automated check
(`public-wire-contract-freeze`) fails our build if any field, route, or error code an already-published
version depends on is removed or renamed, and separately fails if the SDK starts calling an endpoint
nobody has frozen yet. The evidence that it works: `@cnct/locker@0.1.1`, published before this package
existed, still runs unmodified against production today.

And if we ever break the promise anyway, npm is immutable. The version you installed keeps working
because it keeps existing, exactly as you shipped it.

## Getting a client_id

One command, no code:

```sh
npx @cnct/connect register "My App"
```

It prints a public `client_id` to commit as ordinary configuration, plus a registration token that
is **shown once** and is the only way to later update or delete the registration — store it where
you keep secrets. Add `--json` when a script is reading the output; scraping the human format is
how you lose the token. `npx @cnct/connect unregister <client-id> <token>` removes it.

Signing in with `signInPopup()` needs **no redirect URI at all** — the issuer hosts the callback.
Pass your own only if you drive the redirect yourself:

```sh
npx @cnct/connect register "My App" https://myapp.com/callback
```

## No build step at all — one tag

For a site with no bundler and no framework, `<connections-sync>` is the whole integration. It
syncs the listed `localStorage` keys and renders a sign-in / status button that inherits your
page's font and colours (style it via `::part(button)` and `::part(status)`):

```html
<script type="module" src="https://unpkg.com/@cnct/connect/dist/element.js"></script>
<connections-sync client-id="your-public-client-id" keys="theme,density"></connections-sync>
```

Settings living somewhere other than `localStorage`? Assign `read` / `write` on the element and
keep everything else. It emits `connections-signed-in`, `connections-sync-applied`, and
`connections-sync-error`.

## Browser extension (Chrome, Firefox, Safari)

Two pieces, both required. Register your redirect as `identity.getRedirectURL()` — on Chrome that
is `https://<extension-id>.chromiumapp.org/` — and add `"identity"` and `"storage"` to the
manifest permissions.

```ts
import { createConnect, webExtensionStore } from "@cnct/connect";

const connect = createConnect({
  clientId: "your-public-client-id",
  redirectUri: chrome.identity.getRedirectURL(),
  store: webExtensionStore(), // ← not optional; see below
});

const user = await connect.signInExtension(); // opens the consent window, exchanges, persists
const locker = connect.locker();
```

`webExtensionStore()` is load-bearing, not a nicety. An MV3 service worker has **no
`localStorage`**, so the default store silently falls back to memory — and Chrome stops the worker
after ~30 idle seconds, taking the session with it. Nothing throws; the user just gets signed out
over and over. `webExtensionStore()` puts tokens in `storage.local` (or `storage.session` to keep
them off disk), which survives worker restarts.

Driving the flow yourself is still fine — just pass the same redirect URI to both halves, because
the exchange must present the URI the authorize step advertised:

```ts
const redirectUri = chrome.identity.getRedirectURL();
const url = await connect.signIn({ redirect: false, redirectUri });
const returned = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
const user = await connect.handleCallback(returned);
```

Firefox derives its redirect URL from a per-profile UUID, so a Firefox build should register its
own `getRedirectURL()` value (or pass `redirectUri` explicitly).

## Desktop / daemon apps (Node)

For a local single-user daemon or desktop app (the DevWebUI / Reimagine / RepoYeti shape — a
Node process that IS its own backend), use the RFC 8252 loopback flow plus the 0600 file store:

```ts
import { createConnect, nodeFileStore } from "@cnct/connect";

const connect = createConnect({
  clientId: "your-public-client-id",
  redirectUri: "http://127.0.0.1/oauth/callback", // loopback — Connections matches any port
  scopes: ["openid", "profile", "email", "photo"],
  store: nodeFileStore(`${process.env.HOME ?? process.env.USERPROFILE}/.myapp/connections.json`),
});

const user = await connect.signInLoopback(); // binds 127.0.0.1, opens the browser, waits, exchanges
console.log(user.name, user.picture); // display identity — see the identity note below
```

`signInLoopback()` binds an ephemeral loopback port, opens the system browser at the authorize
URL (or hands it to your `openBrowser`), waits for the redirect, exchanges the code, and persists
the session. Refresh is **single-flight and rotation-safe**: concurrent `getAccessToken()` calls
share one refresh (Connections rotates third-party refresh tokens and revokes the whole family on
replay — this client never double-spends), and a revoked session cleanly resolves to signed-out.

## Headless devices (CLIs, SSH, TVs) — device flow

No browser on THIS machine? `signInDeviceFlow()` (RFC 8628) prints a short code the user enters
on any other device, then resolves once they approve:

```ts
const user = await connect.signInDeviceFlow({
  onCode: ({ userCode, verificationUri }) => console.log(`Visit ${verificationUri} and enter ${userCode}`),
});
```

## Verified identity (security inputs)

`idTokenClaims()` is display-only (no signature check). When the identity gates something real —
account linking, an owner check — use **`verifiedIdTokenClaims()`**: RS256 verification against
the issuer's published JWKS (Web Crypto, still zero dependencies) plus iss/aud/exp validation,
with automatic JWKS refresh on key rotation. Throws a `ConnectError` naming exactly what failed.

Signing out of a "disconnect this app" surface? `signOut({ revoke: true })` also revokes the
grant server-side (RFC 7009) — the refresh-token family dies everywhere, not just locally.

## Identity — where the name/email/picture come from

- **`getUser()`** (authoritative) → `GET /oauth/userinfo`: `sub`, `name`, `given_name`,
  `family_name`, `picture` (with the `photo` scope), `email`, plus `entitlements` / `is_paid` /
  `custom_answers`.
- **`idTokenClaims()`** (instant, no network) → the id_token now embeds the same scope-gated
  profile claims (Google's shape), so a display name is available the moment sign-in completes.
- **The email is a privacy relay for third-party apps** — a stable, deliverable, per-(user, app)
  `…@privaterelay.connections.icu` address, never the user's real inbox (Apple Hide-My-Email
  model). Key your accounts on `sub`; treat `email` as a display/delivery address.

### Native apps (Rust / Swift / anything non-Node)

Implement the same five steps this package does — they are deliberately boring: (1) PKCE S256 +
`state`, loopback listener on `127.0.0.1:<any port>`; (2) browser to
`{issuer}/oauth/authorize?...`; (3) exchange the code at `POST {issuer}/oauth/token`
(`code_verifier`, no secret — public client); (4) identity from the id_token claims or
`GET /oauth/userinfo`; (5) on refresh, PERSIST the rotated `refresh_token` every time and
serialize concurrent refreshes (family-revoke on replay). A worked Rust example lives in
QuickDictate's `src/sync.rs`.

## What this is (and isn't)

Security rests on **PKCE + your redirect allowlist + the user's consent** — the `client_id` is
public by design (like Firebase's web apiKey / Stripe's `pk_`). Authorization for the locker
always rides the **user's own token**, so there are no per-user security rules to write and none
to forget. This is NOT a `cnx_pub_` key — that's a separate, broader primitive for calling
first-party data APIs from a browser.
